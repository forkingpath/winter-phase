import { createContainer } from "items-store";
import TodoPage from "containers/TodoPage";

export default createContainer(TodoPage);
