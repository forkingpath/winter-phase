import { createContainer } from "items-store";
import TodoListPage from "containers/TodoListPage";

export default createContainer(TodoListPage);
