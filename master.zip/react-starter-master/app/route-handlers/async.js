// Specify which route handlers should be loaded async.
// the configuration requires this file and adds the
//  react-proxy-loader for specified files
module.exports = ["SomePage", "ReadmePage"];
