import { createContainer } from "items-store";
import NotFoundPage from "containers/NotFoundPage";

export default createContainer(NotFoundPage);
