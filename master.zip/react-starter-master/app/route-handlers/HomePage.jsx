import { createContainer } from "items-store";
import HomePage from "containers/HomePage";

export default createContainer(HomePage);
