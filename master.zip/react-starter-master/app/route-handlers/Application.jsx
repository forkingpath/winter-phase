import { createContainer } from "items-store";
import Application from "containers/Application";

export default createContainer(Application);
