import { createContainer } from "items-store";
import SomePage from "containers/SomePage";

export default createContainer(SomePage);
