import { createContainer } from "items-store";
import ReadmePage from "containers/ReadmePage";

export default createContainer(ReadmePage);
