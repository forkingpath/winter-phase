import { createContainer } from "items-store";
import TodoItemPage from "containers/TodoItemPage";

export default createContainer(TodoItemPage);
