import { createContainer } from "items-store";
import ChatPage from "containers/ChatPage";

export default createContainer(ChatPage);
