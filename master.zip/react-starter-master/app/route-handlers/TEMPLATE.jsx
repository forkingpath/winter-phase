import { createContainer } from "items-store";
import TEMPLATE from "containers/TEMPLATE";

export default createContainer(TEMPLATE);
